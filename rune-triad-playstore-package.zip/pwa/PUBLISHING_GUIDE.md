# Rune Triad: Hidden World — Play Store Publishing Guide

## What's in this package

```
index.html              your game (unchanged logic, now with PWA tags added)
manifest.webmanifest     app name, colors, icons — required for install/TWA
service-worker.js        makes it launch instantly + work offline
icons/                   all icon sizes Android + browsers expect
store-assets/
  feature-graphic.png    1024x500 banner for the Play Store listing page
```

I built the **app shell** (manifest, icons, offline caching, meta tags) — that part is done.
What's left needs tools/accounts I don't have access to from here: hosting, signing, and the
Play Console itself. Here's exactly what to do, in order.

---

## Step 1 — Host it somewhere with HTTPS

A Play Store app built from a website (a "Trusted Web Activity") must point at a **real, live,
HTTPS URL** — not a local file. Easiest free options:

- **Firebase Hosting**, **Netlify**, **Vercel**, or **GitHub Pages** — drag-and-drop the whole
  folder above (keep the file structure exactly as-is) and you'll get a URL like
  `https://rune-triad.netlify.app`.

Upload the *entire folder* (`index.html`, `manifest.webmanifest`, `service-worker.js`, `icons/`),
not just the HTML file — the manifest and icons need to be at the same paths referenced inside
`index.html`.

Once it's live, open it on your phone's Chrome browser — you should see an "Install app" prompt.
If that shows up, the PWA half is working correctly.

---

## Step 2 — Wrap it as an Android app

Use **[PWABuilder.com](https://www.pwabuilder.com)** — no install needed, works in a browser:

1. Paste your hosted URL in.
2. It'll score your manifest/icons (should be green across the board given what's included here).
3. Click **Package for Stores → Android**.
4. Download the generated **Android App Bundle (.aab)**.

(Alternative if you prefer the command line: Google's own
[**Bubblewrap CLI**](https://github.com/GoogleChromeLabs/bubblewrap) does the same thing.)

PWABuilder will also generate a `assetlinks.json` file — upload that to
`https://yourdomain.com/.well-known/assetlinks.json` on your host. This is what lets the Android
app open **without a browser address bar** (a real full-screen app, not "just a website").

---

## Step 3 — Google Play Developer account

- Go to [play.google.com/console](https://play.google.com/console), pay the one-time **$25** fee.
- Takes a few hours to a couple days for identity verification.

---

## Step 4 — Create the store listing

You already have the feature graphic (`store-assets/feature-graphic.png`) and app icon
(`icons/icon-512.png`). You'll still need to prepare, by hand:

- **Phone screenshots** — at least 2, ideally 4-8 (take these by playing the game on a real phone
  or in Chrome DevTools device mode)
- **Short description** (max 80 characters)
- **Full description** (max 4000 characters)
- **Privacy policy URL** — required even for simple games; a one-page "we don't collect personal
  data beyond local save data" statement hosted anywhere works if that's true for your game
- **Content rating questionnaire** — answered inside Play Console itself
- **Target audience / data safety form** — also inside Play Console

## Step 5 — Upload & submit

In Play Console: **Create app → Production → Create new release → upload the .aab from Step 2 →
fill in the listing from Step 4 → submit for review.**

Review typically takes a few hours to a few days for a new developer account's first app.

---

## Notes specific to this game

- `service-worker.js` only caches `index.html` itself — since your whole game (art, audio, code)
  is already inlined as a single file, that's all it needs for offline play.
- If you host at a **subpath** (e.g. `yoursite.com/rune-triad/`) rather than domain root, change
  `start_url`, `scope`, and `id` in `manifest.webmanifest` to match, and the icon paths keep
  working automatically since they're relative.
- **Storage already handled:** progress, session resume, stats, and the leaderboard used to call
  `window.storage`, which only exists inside claude.ai artifacts. I've swapped this for a small
  `Store` wrapper that uses `window.storage` when present and falls back to standard
  `localStorage` automatically — so save/resume/stats work correctly once hosted independently,
  with no further changes needed.
- **One real limitation:** the leaderboard was built on Anthropic's *shared* cross-user storage.
  `localStorage` is per-device only, so once hosted standalone, the leaderboard will show just
  that device's own runs instead of a true global leaderboard (the game now says so in the UI).
  If you want a real cross-player leaderboard on your own hosting, that needs an actual backend
  (e.g. Firebase, Supabase) — a scoped follow-up if/when you want it.

